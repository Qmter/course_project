import sqlite3

con = sqlite3.connect('clinics.db')
cursor = con.cursor()

class doctors():
    def __init__(self, name, last_name, middle_name, login, password, specialization):
        self.login = login
        self.password = password
        self.name = name
        self.last_name = last_name
        self.middle_name = middle_name
        self.specialization = specialization


    def insert_doctor(self):
        cursor.execute(f'insert into doctors (name, last_name, middle_name, login, password, specialization) values (?, ?, ?, ?, ?, ?)', (self.name, self.last_name, self.middle_name, self.login, self.password, self.specialization))
        con.commit()

    def select(self):
        cursor.execute('select id_client, name, last_name, phone from clients')
        users = cursor.fetchall()

        print(*users[-1])




