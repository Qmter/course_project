from DB_appointment import cursor, con, init_database
import customtkinter as ctk
from tkinter.messagebox import showerror
from clients import clients

class UserCabinet(ctk.CTkToplevel):
    def __init__(self, login, password):
        super().__init__()
        init_database()
        
        self.login = login # Store login for later use
        
        self.title("Личный кабинет")
        self.geometry("800x600")
        self.grid_rowconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)
        self.grid_columnconfigure(0, weight=1)

        def print_med_card():
            # Получаем данные медицинской карты
            client = clients(self.login, '', '', self.login, '')  # Создаем экземпляр класса clients
            med_card_data = client.select_med_card()  # Получаем данные медицинской карты
            
            if med_card_data:
                # Записываем данные в текстовый файл
                with open(f'med_card_{self.login}.txt', 'w', encoding='utf-8') as f:
                    f.write(med_card_data[0])  # Записываем мед карту
            else:
                showerror("Ошибка", "Медицинская карта не найдена.")

        self.frame_top = ctk.CTkFrame(master=self, fg_color='#561C24')
        self.frame_top.grid(row=0, column=0, sticky="nsew")

        self.frame_down = ctk.CTkFrame(master=self, fg_color='#C7B7A3')
        self.frame_down.grid(row=1, column=0, sticky="nsew")

        # Получаем данные пользователя из БД
        cursor.execute("SELECT id_client, name, last_name, middle_name FROM clients WHERE login = ? AND password = ?", (login, password))
        user_data = cursor.fetchone()

        if not user_data:
            showerror("Ошибка", "Пользователь не найден. Проверьте логин и пароль.")
            return  # Прекращаем выполнение, если пользователь не найден

        # Создаем и размещаем метки с информацией
        self.label_id = ctk.CTkLabel(master=self.frame_top,
                                   text=f"ID: {user_data[0]}",
                                   fg_color='#561C24',
                                   text_color='white',
                                   font=("Arial", 15, "bold"))
        self.label_id.place(x=20, y=20)

        self.label_name = ctk.CTkLabel(master=self.frame_top,
                                     text=f"Имя: {user_data[1]}",
                                     fg_color='#561C24',
                                     text_color='white',
                                     font=("Arial", 15, "bold"))
        self.label_name.place(x=20, y=50)

        self.label_lastname = ctk.CTkLabel(master=self.frame_top,
                                         text=f"Фамилия: {user_data[2]}",
                                         fg_color='#561C24',
                                         text_color='white',
                                         font=("Arial", 15, "bold"))
        self.label_lastname.place(x=20, y=80)

        self.label_patronymic = ctk.CTkLabel(master=self.frame_top,
                                         text=f"Отчество: {user_data[3]}",
                                         fg_color='#561C24',
                                         text_color='white',
                                         font=("Arial", 15, "bold"))
        self.label_patronymic.place(x=20, y=110)

        self.btn_med_card = ctk.CTkButton(master=self.frame_top, text='Просмотреть медицинскую карту', command=print_med_card, fg_color='#C7B7A3', text_color='black')
        self.btn_med_card.place(x=20, y=140)

        # Получаем записи пользователя из БД
        cursor.execute("""
            SELECT a.date, a.now_time, d.name || ' ' || d.last_name AS full_name, d.specialization 
            FROM appointments a
            JOIN doctors d ON a.id_doctor = d.id_doctor
            WHERE a.id_client = ?
            ORDER BY date, now_time
        """, (user_data[0],))
        appointments = cursor.fetchall()

        # Создаем фрейм для списка записей
        self.appointments_frame = ctk.CTkFrame(master=self.frame_down, fg_color='#E8D8C4')
        self.appointments_frame.pack(pady=20, padx=20, fill="both", expand=True)

        # Заголовок для списка записей
        self.appointments_label = ctk.CTkLabel(
            master=self.appointments_frame,
            text="Ваши ближайшие записи:",
            fg_color='#E8D8C4',
            text_color='black',
            font=("Arial", 16, "bold")
        )
        self.appointments_label.pack(pady=10)

        # Создаем кнопку для новой записи
        self.new_appointment_button = ctk.CTkButton(
            master=self.appointments_frame,
            text="Записаться на прием",
            fg_color='#6D2932',
            command=self.open_appointment_window,
            font=("Arial", 15, "bold")
        )
        self.new_appointment_button.pack(pady=10)

        if appointments:
            for date, time, doctor_name, specialization in appointments:
                appointment_text = f"Дата: {date} | Время: {time}\nВрач: {doctor_name} | Специализация: {specialization}"
                appointment_label = ctk.CTkLabel(
                    master=self.appointments_frame,
                    text=appointment_text,
                    fg_color='#E8D8C4',
                    text_color='black',
                    font=("Arial", 15, "bold")
                )
                appointment_label.pack(pady=5)
                
                # Добавляем кнопку для печати талона
                print_button = ctk.CTkButton(
                    master=self.appointments_frame,
                    text="Распечатать талон",
                    fg_color='#6D2932',
                    command=lambda d=date, t=time, doc=doctor_name, spec=specialization: 
                        self.print_appointment(d, t, doc, spec),
                    font=("Arial", 15, "bold")
                )
                print_button.pack(pady=5)
                
                # Добавляем кнопку для удаления записи
                delete_button = ctk.CTkButton(
                    master=self.appointments_frame,
                    text="Удалить запись",
                    fg_color='#6D2932',
                    command=lambda d=date, t=time, doc=doctor_name, spec=specialization: 
                        self.delete_appointment(d, t, doc, spec),
                    font=("Arial", 15, "bold")
                )
                delete_button.pack(pady=5)
        else:
            no_appointments_label = ctk.CTkLabel(
                master=self.appointments_frame,
                text="У вас пока нет записей",
                fg_color='#E8D8C4',
                text_color='black',
                font=("Arial", 15, "bold")
            )
            no_appointments_label.pack(pady=10)

    def print_appointment(self, date, time, doctor_name, specialization):
        # Получаем данные пациента
        cursor.execute("SELECT name, last_name FROM clients WHERE login = ?", (self.login,))
        patient_data = cursor.fetchone()
        
        # Формируем текст талона
        talon_text = f"""
=== ТАЛО�� НА ПРИЕМ ===
Пациент: {patient_data[0]} {patient_data[1]}
Дата приема: {date}
Время приема: {time}
Врач: {doctor_name}
Специализация: {specialization}
=====================
"""
        # Сохраняем талон в файл
        with open(f'talon_{date}_{time.replace(":", "-")}.txt', 'w', encoding='utf-8') as f:
            f.write(talon_text)

    def open_appointment_window(self):
        # Создаем новое окно для записи
        self.appointment_window = ctk.CTkToplevel()
        self.appointment_window.title("Запись на прием")
        self.appointment_window.geometry("500x400")
        
        # Получаем список врачей
        cursor.execute("SELECT id_doctor, name, last_name, middle_name, specialization FROM doctors")
        doctors = cursor.fetchall()
        
        # Создаем выпадающий список врачей
        doctor_options = [f"{doc[1]} {doc[2]} {doc[3]} - {doc[4]}" for doc in doctors]
        self.doctor_var = ctk.StringVar(value=doctor_options[0] if doctor_options else "")
        self.doctor_menu = ctk.CTkOptionMenu(
            master=self.appointment_window,
            values=doctor_options,
            variable=self.doctor_var,
            font=("Arial", 15, "bold")
        )
        self.doctor_menu.pack(pady=10)
        
        # Поле для ввода даты
        self.date_entry = ctk.CTkEntry(
            master=self.appointment_window,
            placeholder_text="Дата (ГГГГ-ММ-ДД)",
            font=("Arial", 15, "bold")
        )
        self.date_entry.pack(pady=10)
        
        # Поле для ввода времени
        self.time_entry = ctk.CTkEntry(
            master=self.appointment_window,
            placeholder_text="Время (ЧЧ:ММ)",
            font=("Arial", 15, "bold")
        )
        self.time_entry.pack(pady=10)
        
        # Кнопка подтверждения записи
        self.confirm_button = ctk.CTkButton(
            master=self.appointment_window,
            text="Подтвердить запись",
            fg_color='#6D2932',
            command=self.create_appointment,
            font=("Arial", 15, "bold")
        )
        self.confirm_button.pack(pady=10)
        
    def create_appointment(self):
        # Получаем выбранного врача
        doctor_full_name = self.doctor_var.get().split(" - ")[0]
        cursor.execute("SELECT id_doctor FROM doctors WHERE name = ? AND last_name = ?", (doctor_full_name.split(" ")[0], doctor_full_name.split(" ")[1]))
        doctor_id = cursor.fetchone()[0]
        
        # Получаем id клиента
        cursor.execute("SELECT id_client FROM clients WHERE login = ?", (self.login,))
        client_id = cursor.fetchone()[0]
        
        # Проверяем, нет ли уже записи на это время к этому врачу
        cursor.execute("""
            SELECT COUNT(*) FROM appointments 
            WHERE id_doctor = ? AND date = ? AND now_time = ?
        """, (doctor_id, self.date_entry.get(), self.time_entry.get()))
        
        if cursor.fetchone()[0] > 0:
            showerror("Ошибка", "На это время уже есть запись к данному врачу. Пожалуйста, выберите другое время.")
            return
            
        # Создаем новую запись
        cursor.execute("""
            INSERT INTO appointments (id_client, id_doctor, date, now_time)
            VALUES (?, ?, ?, ?)
        """, (client_id, doctor_id, self.date_entry.get(), self.time_entry.get()))
        con.commit()
        
        # Закрываем окно записи и обновляем список записей
        self.appointment_window.destroy()
        self.update_appointments_list()
        
    def update_appointments_list(self):
        # Очищаем текущий список записей
        for widget in self.appointments_frame.winfo_children():
            if widget != self.appointments_label and widget != self.new_appointment_button:
                widget.destroy()
        
        # Получаем обновленный список записей
        cursor.execute("""
            SELECT a.date, a.now_time, d.name || ' ' || d.last_name AS full_name, d.specialization 
            FROM appointments a
            JOIN doctors d ON a.id_doctor = d.id_doctor
            WHERE a.id_client = (SELECT id_client FROM clients WHERE login = ?)
            ORDER BY date, now_time
        """, (self.login,))
        appointments = cursor.fetchall()
        
        if appointments:
            for date, time, doctor_name, specialization in appointments:
                appointment_text = f"Дата: {date} | Время: {time}\nВрач: {doctor_name} | Специализация: {specialization}"
                appointment_label = ctk.CTkLabel(
                    master=self.appointments_frame,
                    text=appointment_text,
                    fg_color='#E8D8C4',
                    text_color='black',
                    font=("Arial", 15, "bold")
                )
                appointment_label.pack(pady=5)
                
                # Добавляем кнопку для печати талона
                print_button = ctk.CTkButton(
                    master=self.appointments_frame,
                    text="Распечатать талон",
                    fg_color='#6D2932',
                    command=lambda d=date, t=time, doc=doctor_name, spec=specialization: 
                        self.print_appointment(d, t, doc, spec),
                    font=("Arial", 15, "bold")
                )
                print_button.pack(pady=5)
                
                # Добавляем кнопку для удаления записи
                delete_button = ctk.CTkButton(
                    master=self.appointments_frame,
                    text="Удалить запись",
                    fg_color='#6D2932',
                    command=lambda d=date, t=time, doc=doctor_name, spec=specialization: 
                        self.delete_appointment(d, t, doc, spec),
                    font=("Arial", 15, "bold")
                )
                delete_button.pack(pady=5)
        else:
            no_appointments_label = ctk.CTkLabel(
                master=self.appointments_frame,
                text="У вас пока нет записей",
                fg_color='#E8D8C4',
                text_color='black',
                font=("Arial", 15, "bold")
            )
            no_appointments_label.pack(pady=10)

    def delete_appointment(self, date, time, doctor_name, specialization):
        # Получаем id клиента
        cursor.execute("SELECT id_client FROM clients WHERE login = ?", (self.login,))
        client_id = cursor.fetchone()[0]
        
        # Получаем id врача
        cursor.execute("SELECT id_doctor FROM doctors WHERE name = ? AND last_name = ?", (doctor_name.split(" ")[0], doctor_name.split(" ")[1]))
        doctor_id = cursor.fetchone()[0]
        
        # Удаляем запись
        cursor.execute("""
            DELETE FROM appointments 
            WHERE id_client = ? AND id_doctor = ? AND date = ? AND now_time = ?
        """, (client_id, doctor_id, date, time))
        con.commit()
        
        # Обновляем список записей
        self.update_appointments_list()