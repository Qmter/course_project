from register_clients import *
from autorisation_doctor import *
import customtkinter
from clients import *
from cabinet import *

class autorisation(customtkinter.CTk):
    def __init__(self):
        super().__init__()
        self.geometry('1280x720')
        self.title('Hospital')
        customtkinter.set_appearance_mode('system')

        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        self.UserForm = None
        self.UserCabinet = None

        def open_doc_autorisation():
            autorisation.destroy(self)
            self.registration_window = autorisation_doctor()
            self.registration_window.mainloop()  

        def open_toplevel():
            if self.UserForm is None or not self.UserForm.winfo_exists():
                self.toplevel_window = UserForm()
            else:
                self.toplevel_window.focus()

        def enter_in_acc():
            a = check.check_user(self.entry_log.get(), self.entry_pass.get()).check_user()
            if a:
                if self.UserCabinet is None or not self.UserCabinet.winfo_exists():
                    self.window = UserCabinet(self.entry_log.get(), self.entry_pass.get())
                    autorisation.withdraw(self)
                else:
                    self.window.focus()
            else:
                showinfo(title="Регистрация", message="Неверный логин или пароль")



        self.frame_left = customtkinter.CTkFrame(master=self, fg_color='#561C24')
        self.frame_left.grid(row=0, column=0, sticky="nesw")

        self.frame_left.columnconfigure(0, weight=1)
        self.frame_left.columnconfigure(1, weight=1)
        self.frame_left.columnconfigure(2, weight=1)
        self.frame_left.columnconfigure(3, weight=1)
        self.frame_left.rowconfigure(0, weight=1)
        self.frame_left.rowconfigure(1, weight=1)
        self.frame_left.rowconfigure(2, weight=1)
        self.frame_left.rowconfigure(3, weight=1)

        self.frame_left_autorisation = customtkinter.CTkFrame(master=self.frame_left, width=450, height=300,  fg_color='#E8D8C4')
        self.frame_left_autorisation.grid(row=1, column=1, columnspan=2, rowspan=2)

        self.lable_log = customtkinter.CTkLabel(master=self.frame_left_autorisation, fg_color='#E8D8C4', text_color='black', text='Логин')
        self.lable_log.place(x=190, y=50)

        self.entry_log = customtkinter.CTkEntry(master=self.frame_left_autorisation, placeholder_text='Введите логин:', width=250)
        self.entry_log.place(x=100, y=90)

        self.lable_pass = customtkinter.CTkLabel(master=self.frame_left_autorisation, fg_color='#E8D8C4', text_color='black', text='Пароль')
        self.lable_pass.place(x=190, y=130)

        self.entry_pass = customtkinter.CTkEntry(master=self.frame_left_autorisation, placeholder_text='Введите пароль:', width=250)
        self.entry_pass.place(x=100, y=170)

        self.btn_entry = customtkinter.CTkButton(master=self.frame_left_autorisation, text='Войти', command=enter_in_acc, fg_color='#6D2932')
        self.btn_entry.place(x=150, y=210)

        self.btn_entry = customtkinter.CTkButton(master=self.frame_left_autorisation, text='Войти как врач', command=open_doc_autorisation, fg_color='#6D2932')
        self.btn_entry.place(x=300, y=210)



        self.btn_register = customtkinter.CTkButton(master=self.frame_left_autorisation, text='Регистрация', command=open_toplevel, fg_color='#6D2932')
        self.btn_register.place(x=150, y=265)

        self.frame__right = customtkinter.CTkFrame(master=self, fg_color="#C7B7A3")
        self.frame__right.grid(row=0, column=1, sticky="nesw")
