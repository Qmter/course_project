import sqlite3

con = sqlite3.connect('clinics.db')
cursor = con.cursor()
class clients():
    def __init__(self, name, last_name, middle_name, login, password):
        self.login = login
        self.password = password
        self.name = name
        self.last_name = last_name
        self.middle_name = middle_name

    def insert_user(self):
        cursor.execute(f'insert into clients (name, last_name, middle_name, login, password) values (?, ?, ?, ?, ?)', (self.name, self.last_name, self.middle_name, self.login, self.password))
        con.commit()

    def select_med_card(self):
        cursor.execute('select med_card from medical_card where id_client = (select id_client from clients where login = ?)', (self.login,))
        return cursor.fetchone()





