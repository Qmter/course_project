from DB_appointment import cursor, con, init_database
import customtkinter as ctk
from tkinter.messagebox import showerror
from clients import clients

class DoctorCabinet(ctk.CTkToplevel):
    def __init__(self, login, password):
        super().__init__()
        init_database()
        
        self.login = login # Store login for later use
        
        self.title("Личный кабинет")
        self.geometry("800x600")
        self.grid_rowconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)
        self.grid_columnconfigure(0, weight=1)

        self.frame_top = ctk.CTkFrame(master=self, fg_color='#561C24')
        self.frame_top.grid(row=0, column=0, sticky="nsew")

        self.frame_down = ctk.CTkFrame(master=self, fg_color='#C7B7A3')
        self.frame_down.grid(row=1, column=0, sticky="nsew")

        cursor.execute("SELECT id_doctor, name, last_name, middle_name, specialization FROM doctors WHERE login = ? AND password = ?", (login, password))
        self.user_data = cursor.fetchone()

        if not self.user_data:
            showerror("Ошибка", "Пользователь не найден. Проверьте логин и пароль.")
            return  # Прекращаем выполнение, если пользователь не найден

        # Создаем и размещаем метки с информацией
        self.label_id = ctk.CTkLabel(master=self.frame_top,
                                   text=f"ID: {self.user_data[0]}",
                                   fg_color='#561C24',
                                   text_color='white',
                                   font=("Arial", 15, "bold"))
        self.label_id.place(x=20, y=20)

        self.label_name = ctk.CTkLabel(master=self.frame_top,
                                     text=f"Имя: {self.user_data[1]}",
                                     fg_color='#561C24',
                                     text_color='white',
                                     font=("Arial", 15, "bold"))
        self.label_name.place(x=20, y=50)

        self.label_lastname = ctk.CTkLabel(master=self.frame_top,
                                         text=f"Фамилия: {self.user_data[2]}",
                                         fg_color='#561C24',
                                         text_color='white',
                                         font=("Arial", 15, "bold"))
        self.label_lastname.place(x=20, y=80)

        self.label_patronymic = ctk.CTkLabel(master=self.frame_top,
                                         text=f"Отчество: {self.user_data[3]}",
                                         fg_color='#561C24',
                                         text_color='white',
                                         font=("Arial", 15, "bold"))
        self.label_patronymic.place(x=20, y=110)

        self.label_specialization = ctk.CTkLabel(master=self.frame_top,
                                         text=f"Специальность: {self.user_data[4]}",
                                         fg_color='#561C24',
                                         text_color='white',
                                         font=("Arial", 15, "bold"))
        self.label_specialization.place(x=20, y=140)

        # Создаем кнопку для добавления записи в медицинскую книжку
        self.btn_add_med_record = ctk.CTkButton(
            master=self.frame_top,
            text='Добавить запись в мед. книжку',
            command=self.add_medical_record,
            fg_color='#C7B7A3',
            text_color='black'
        )
        self.btn_add_med_record.place(x=20, y=170)

        # Получаем записи для данног врача
        cursor.execute("SELECT a.date, a.now_time, c.name, c.last_name, c.middle_name, c.id_client FROM appointments a JOIN clients c ON a.id_client = c.id_client WHERE a.id_doctor = ?", (int(self.user_data[0]),))
        self.appointments = cursor.fetchall()

        # Создаем метки для отображения записей
        for index, appointment in enumerate(self.appointments):
            label_appointment = ctk.CTkLabel(master=self.frame_down,
                                               text=f"Запись {index + 1}: {appointment[0]} {appointment[1]} - Пациент: {appointment[2]} {appointment[3]} {appointment[4]}",
                                               fg_color='#C7B7A3',
                                               text_color='black',
                                               font=("Arial", 12))
            label_appointment.pack(anchor='w', padx=20, pady=5)

            # Добавляем кнопку для добавления записи в мед. карту рядом с каждой записью
            btn_add_med_record = ctk.CTkButton(
                master=self.frame_down,
                text='Добавить в мед. карту',
                command=self.add_medical_record,
                fg_color='#C7B7A3',
                text_color='black'
            )
            btn_add_med_record.pack(anchor='w', padx=20, pady=5)

    def add_medical_record(self):
        # Открываем новое окно для ввода данных медицинской записи
        self.med_record_window = ctk.CTkToplevel(self)
        self.med_record_window.title("Добавить запись в медицинскую книжку")
        self.med_record_window.geometry("400x300")

        # Поле для ввода данных медицинской записи
        self.med_record_entry = ctk.CTkEntry(
            master=self.med_record_window,
            placeholder_text="Введите данные медицинской записи",
            font=("Arial", 12),
            width=100,
            height=100
        )
        self.med_record_entry.pack(pady=20)

        # Кнопка для подтверждения добавления записи
        self.confirm_button = ctk.CTkButton(
            master=self.med_record_window,
            text="Добавить",
            command=self.save_medical_record,
            fg_color='#6D2932'
        )
        self.confirm_button.pack(pady=10)

    def save_medical_record(self):
        # Получаем данные из поля ввода
        med_record_data = self.med_record_entry.get()

        # Извлекаем дату и время из первой записи
        appointment_date = self.appointments[0][0]  # Дата
        appointment_time = self.appointments[0][1]  # Время

        cursor.execute("SELECT c.id_client FROM appointments a JOIN clients c ON a.id_client = c.id_client WHERE a.date = ? AND a.now_time = ? AND a.id_doctor = ?", (appointment_date, appointment_time, int(self.user_data[0])))
        client_id = cursor.fetchone()

        if client_id:
            # Проверяем, существует ли запись в медицинской карте
            cursor.execute("SELECT med_card FROM medical_card WHERE id_client = ?", (client_id[0],))
            existing_record = cursor.fetchone()

            if existing_record:
                # Обновляем запись в медицинской книжке
                cursor.execute("UPDATE medical_card SET med_card = ? WHERE id_client = ?", (med_record_data, client_id[0]))
            else:
                # Вставляем новую запись в медицинскую книжку
                cursor.execute("INSERT INTO medical_card (id_client, med_card) VALUES (?, ?)", (client_id[0], med_record_data))

            con.commit()
        else:
            showerror("Ошибка", "Запись не найдена для указанного времени и доктора.")

        # Закрываем окно
        self.med_record_window.destroy()