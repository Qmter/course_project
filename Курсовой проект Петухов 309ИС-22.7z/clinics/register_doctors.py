from doctors import *
import check
from tkinter.messagebox import showerror, showwarning, showinfo
import customtkinter

class DoctorForm(customtkinter.CTkToplevel):
    def __init__(self):
        super().__init__()
        self.geometry('800x600')
        self.title('Hospital')
        self.configure(fg_color="#ff6666")
        customtkinter.set_appearance_mode('system')

        spesialisation = ['Хирург', 'Ортопед', 'Психиатор', 'Отоларинголог', 'Офтальмолог']
        spesialisation_options = [spec for spec in spesialisation]

        def register():
            if check.check_user(self.entry_register_password.get(), self.entry_register_login.get()).check_doctor_register():
                showinfo(title="Регистрация", message="Пользователь с таким логином уже существует")
                self.destroy()
            else:
                doctor = doctors(self.entry_register_name.get(), self.entry_register_LastName.get(), self.entry_register_MiddleName.get(), self.entry_register_login.get(), self.entry_register_password.get(), self.specialisation_var.get()).insert_doctor()
                showinfo(title="Регистрация", message="Аккаунт зарегистрирован")

                self.destroy()
            
            doctor = doctors(
                self.entry_register_name.get(),
                self.entry_register_LastName.get(),
                self.entry_register_MiddleName.get(),
                self.entry_register_login.get(),
                self.entry_register_password.get(),
                self.specialisation_var.get()
            ).insert_doctor()
            showinfo(title="Регистрация", message="Аккаунт зарегистрирован")

        self.columnconfigure(0, weight=1)
        self.columnconfigure(1, weight=1)
        self.columnconfigure(2, weight=1)
        self.columnconfigure(3, weight=1)
        self.rowconfigure(0, weight=1)
        self.rowconfigure(1, weight=1)
        self.rowconfigure(2, weight=1)
        self.rowconfigure(3, weight=1)

        self.frame_register = customtkinter.CTkFrame(master=self, width=450, height=300,  fg_color='#ffe5e0')
        self.frame_register.grid(row=1, column=1, columnspan=2, rowspan=2)


        self.lable_register_login = customtkinter.CTkLabel(master=self.frame_register, fg_color='#ffe5e0', text_color='black', text='Логин')
        self.lable_register_login.place(x=30, y=30)

        self.entry_register_login = customtkinter.CTkEntry(master=self.frame_register, placeholder_text='Введите логин:', width=250)
        self.entry_register_login.place(x=100, y=30)

        self.lable_register_password = customtkinter.CTkLabel(master=self.frame_register, fg_color='#ffe5e0', text_color='black', text='Пароль')
        self.lable_register_password.place(x=30, y=70)

        self.entry_register_password = customtkinter.CTkEntry(master=self.frame_register, placeholder_text='Введите пароль: ', width=250)
        self.entry_register_password.place(x=100, y=70)

        self.lable_register_name = customtkinter.CTkLabel(master=self.frame_register, fg_color='#ffe5e0', text_color='black', text='Имя')
        self.lable_register_name.place(x=30, y=110)

        self.entry_register_name = customtkinter.CTkEntry(master=self.frame_register, placeholder_text='Имя: ', width=250)
        self.entry_register_name.place(x=100, y=110)

        self.lable_register_LastName = customtkinter.CTkLabel(master=self.frame_register, fg_color='#ffe5e0', text_color='black', text='Фамилия')
        self.lable_register_LastName.place(x=30, y=150)

        self.entry_register_LastName = customtkinter.CTkEntry(master=self.frame_register, placeholder_text='Фамилия: ', width=250)
        self.entry_register_LastName.place(x=100, y=150)

        self.lable_register_MiddleName= customtkinter.CTkLabel(master=self.frame_register, fg_color='#ffe5e0', text_color='black', text='Отчество')
        self.lable_register_MiddleName.place(x=30, y=190)

        self.entry_register_MiddleName = customtkinter.CTkEntry(master=self.frame_register, placeholder_text='Отчество: ', width=250)
        self.entry_register_MiddleName.place(x=100, y=190)
        
        self.entry_register_specialization = customtkinter.CTkLabel(master=self.frame_register, fg_color='#ffe5e0', text_color='black', text='Специальность')
        self.entry_register_specialization.place(x=30, y=230)

        self.specialisation_var = customtkinter.StringVar(value=spesialisation_options[0] if spesialisation_options else "")
        self.entry_register_specialization  = customtkinter.CTkOptionMenu(
            master=self.frame_register,
            values=spesialisation_options,
            variable=self.specialisation_var,
            font=("Arial", 15, "bold")
        )
        self.entry_register_specialization.place(x=200, y=230)

        

        self.lable_register_type = customtkinter.CTkLabel(master=self.frame_register, fg_color='#ffe5e0', text_color='black', text='Регистрация врача')
        self.lable_register_type.place(x=30, y=0)

        self.btn_registration = customtkinter.CTkButton(master=self.frame_register, text='Регистрация', command=register, fg_color='#C7B7A3')
        self.btn_registration.place(x=150, y=270)

        self.grab_set()
