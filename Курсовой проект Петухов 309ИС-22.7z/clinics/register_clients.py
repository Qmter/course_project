from clients import *
from doctors import *
from register_doctors import *
import check
from tkinter.messagebox import showerror, showwarning, showinfo
import customtkinter


class UserForm(customtkinter.CTkToplevel):
    def __init__(self):
        super().__init__()
        self.geometry('800x600')
        self.title('Hospital')
        self.configure(fg_color="#ff6666")
        customtkinter.set_appearance_mode('system')

        def register_doctor():
            UserForm.destroy(self)
            self.registration_window = DoctorForm()
            self.registration_window.mainloop()  



        def register():
            if check.check_user(self.entry_register_password.get(), self.entry_register_login.get()).check_register():
                showinfo(title="Регистрация", message="Пользователь с таким логином уже существует")
                self.destroy()
            else:
                client = clients(self.entry_register_name.get(), self.entry_register_LastName.get(), self.entry_register_MiddleName.get(), self.entry_register_login.get(), self.entry_register_password.get()).insert_user()
                showinfo(title="Регистрация", message="Аккаунт зарегистрирован")
            
            self.destroy()

        self.columnconfigure(0, weight=1)
        self.columnconfigure(1, weight=1)
        self.columnconfigure(2, weight=1)
        self.columnconfigure(3, weight=1)
        self.rowconfigure(0, weight=1)
        self.rowconfigure(1, weight=1)
        self.rowconfigure(2, weight=1)
        self.rowconfigure(3, weight=1)

        self.frame_register = customtkinter.CTkFrame(master=self, width=450, height=300,  fg_color='#ffe5e0')
        self.frame_register.grid(row=1, column=1, columnspan=2, rowspan=2)


        self.lable_register_login = customtkinter.CTkLabel(master=self.frame_register, fg_color='#ffe5e0', text_color='black', text='Логин')
        self.lable_register_login.place(x=30, y=60)

        self.entry_register_login = customtkinter.CTkEntry(master=self.frame_register, placeholder_text='Введите логин:', width=250)
        self.entry_register_login.place(x=100, y=60)

        self.lable_register_password = customtkinter.CTkLabel(master=self.frame_register, fg_color='#ffe5e0', text_color='black', text='Пароль')
        self.lable_register_password.place(x=30, y=100)

        self.entry_register_password = customtkinter.CTkEntry(master=self.frame_register, placeholder_text='Введите пароль: ', width=250)
        self.entry_register_password.place(x=100, y=100)

        self.lable_register_name = customtkinter.CTkLabel(master=self.frame_register, fg_color='#ffe5e0', text_color='black', text='Имя')
        self.lable_register_name.place(x=30, y=140)

        self.entry_register_name = customtkinter.CTkEntry(master=self.frame_register, placeholder_text='Имя: ', width=250)
        self.entry_register_name.place(x=100, y=140)

        self.lable_register_LastName = customtkinter.CTkLabel(master=self.frame_register, fg_color='#ffe5e0', text_color='black', text='Фамилия')
        self.lable_register_LastName.place(x=30, y=180)

        self.entry_register_LastName = customtkinter.CTkEntry(master=self.frame_register, placeholder_text='Фамилия: ', width=250)
        self.entry_register_LastName.place(x=100, y=180)

        self.lable_register_MiddleName= customtkinter.CTkLabel(master=self.frame_register, fg_color='#ffe5e0', text_color='black', text='Отчество')
        self.lable_register_MiddleName.place(x=30, y=220)

        self.entry_register_MiddleName = customtkinter.CTkEntry(master=self.frame_register, placeholder_text='Отчество: ', width=250)
        self.entry_register_MiddleName.place(x=100, y=220)

        self.lable_register_type = customtkinter.CTkLabel(master=self.frame_register, fg_color='#ffe5e0', text_color='black', text='Регистрация:')
        self.lable_register_type.place(x=30, y=0)

        self.btn_registration = customtkinter.CTkButton(master=self.frame_register, text='Регистрация', command=register, fg_color='#C7B7A3')
        self.btn_registration.place(x=150, y=250)

        self.btn_registration = customtkinter.CTkButton(master=self.frame_register, text='Я врач', command=register_doctor, fg_color='#C7B7A3')
        self.btn_registration.place(x=300, y=250)

        self.grab_set()