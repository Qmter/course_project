from DB_appointment import cursor


class check_user:
    def __init__(self, login, password):
        self.login = login
        self.password = password

    def check_user(self):
        cursor.execute('select * from clients where login=? and password=?', (self.login, self.password))
        if cursor.fetchone() is not None:
            return True
        return False

    def check_register(self):
        check_register = 'select login from clients where login = ? or password = ?'
        cursor.execute(check_register, (self.login, self.password))
        if cursor.fetchone() is not None:
            return True
        return False
    
    def check_doctor_register(self):
        check_register = 'select login from doctors where login = ? or password = ?'
        cursor.execute(check_register, (self.login, self.password))
        if cursor.fetchone() is not None:
            return True
        return False
    
    def check_doctor(self):
        cursor.execute('select * from doctors where login=? and password=?', (self.login, self.password))
        if cursor.fetchone() is not None:
            return True
        return False

