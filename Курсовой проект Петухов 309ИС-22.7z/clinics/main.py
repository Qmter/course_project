import DB_appointment
from clients import *
import customtkinter
from tkinter.messagebox import showerror, showwarning, showinfo
from autorisation import *
from register_clients import *

class ClinicApp(customtkinter.CTk):
    init_database()
    def __init__(self):
        super().__init__()

        self.autorisation_window = autorisation()
        self.autorisation_window.mainloop()  

if __name__ == '__main__':
    app = ClinicApp()
    app.mainloop()