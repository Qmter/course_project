import sqlite3
con = sqlite3.connect('clients16.db')
cursor = con.cursor()


cursor.execute("SELECT med_card FROM medical_card WHERE id_client = 4")
existing_record = cursor.fetchone()

if existing_record is not None:
    for i in existing_record:
        print(*i)
else:
    print("Запись не найдена.")