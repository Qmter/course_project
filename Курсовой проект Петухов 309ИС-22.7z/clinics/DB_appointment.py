import sqlite3
con = sqlite3.connect('clinics.db')
cursor = con.cursor()

def init_database():

    # Создание таблиц
    cursor.execute("""create table if not exists doctors(
        id_doctor integer primary key autoincrement,
        name varchar(255),
        last_name varchar(255),
        middle_name varchar(255),
        login varchar(255),
        password varchar(255),
        specialization varchar(255)
    )""")

    # Создание остальных таблиц
    cursor.execute("""create table if not exists clients(
        id_client integer primary key autoincrement,
        name varchar(255),
        last_name varchar(255),
        middle_name varchar(255),
        login varchar(255),
        password varchar(255)
    )""")
    
    cursor.execute("""create table if not exists appointments(
        id_appointment integer primary key autoincrement,
        id_client integer,
        id_doctor integer,
        now_time varchar(255),
        date varchar(255),
        foreign key (id_client) references clients(id_client),
        foreign key (id_doctor) references doctors(id_doctor)
    )""")

    cursor.execute("""create table if not exists medical_card(
        id_medical_card integer primary key autoincrement,
        id_client integer,
        med_card varchar(1024),
        foreign key (id_client) references clients(id_client)
    )""")
    
    con.commit()